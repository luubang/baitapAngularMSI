import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap2-contact',
  templateUrl: './baitap2-contact.component.html',
  styleUrls: ['./baitap2-contact.component.scss']
})
export class Baitap2ContactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
