import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap2-header',
  templateUrl: './baitap2-header.component.html',
  styleUrls: ['./baitap2-header.component.scss']
})
export class Baitap2HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
