import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap2-item-card',
  templateUrl: './baitap2-item-card.component.html',
  styleUrls: ['./baitap2-item-card.component.scss']
})
export class Baitap2ItemCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
