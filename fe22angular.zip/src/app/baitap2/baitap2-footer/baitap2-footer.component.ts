import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap2-footer',
  templateUrl: './baitap2-footer.component.html',
  styleUrls: ['./baitap2-footer.component.scss']
})
export class Baitap2FooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
