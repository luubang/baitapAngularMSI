import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap2-list',
  templateUrl: './baitap2-list.component.html',
  styleUrls: ['./baitap2-list.component.scss']
})
export class Baitap2ListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
