import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap1-content',
  templateUrl: './baitap1-content.component.html',
  styleUrls: ['./baitap1-content.component.scss']
})
export class Baitap1ContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
