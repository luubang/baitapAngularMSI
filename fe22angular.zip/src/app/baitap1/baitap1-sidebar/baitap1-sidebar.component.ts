import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap1-sidebar',
  templateUrl: './baitap1-sidebar.component.html',
  styleUrls: ['./baitap1-sidebar.component.scss']
})
export class Baitap1SidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
