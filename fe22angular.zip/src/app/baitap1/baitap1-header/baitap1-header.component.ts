import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap1-header',
  templateUrl: './baitap1-header.component.html',
  styleUrls: ['./baitap1-header.component.scss']
})
export class Baitap1HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
