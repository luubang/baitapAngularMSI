import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap1-footer',
  templateUrl: './baitap1-footer.component.html',
  styleUrls: ['./baitap1-footer.component.scss']
})
export class Baitap1FooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
