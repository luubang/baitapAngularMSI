import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap3-header',
  templateUrl: './baitap3-header.component.html',
  styleUrls: ['./baitap3-header.component.scss']
})
export class Baitap3HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
