import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap3',
  templateUrl: './baitap3.component.html',
  styleUrls: ['./baitap3.component.scss']
})
export class Baitap3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
